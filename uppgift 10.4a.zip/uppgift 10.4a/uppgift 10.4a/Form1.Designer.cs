﻿namespace uppgift_10._4a
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.tbxAntal = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btn_check = new System.Windows.Forms.Button();
            this.btnforestgreen = new System.Windows.Forms.Button();
            this.btnDarkturkuas = new System.Windows.Forms.Button();
            this.btnLime = new System.Windows.Forms.Button();
            this.btnYellow = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(300, 15);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(100, 25);
            this.button1.TabIndex = 0;
            this.button1.Text = "Rita";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // tbxAntal
            // 
            this.tbxAntal.Location = new System.Drawing.Point(85, 15);
            this.tbxAntal.Margin = new System.Windows.Forms.Padding(4);
            this.tbxAntal.Name = "tbxAntal";
            this.tbxAntal.Size = new System.Drawing.Size(205, 22);
            this.tbxAntal.TabIndex = 1;
            this.tbxAntal.TextChanged += new System.EventHandler(this.tbxAntal_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(20, 23);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 16);
            this.label1.TabIndex = 2;
            this.label1.Text = "Antal:";
            // 
            // btn_check
            // 
            this.btn_check.Location = new System.Drawing.Point(300, 109);
            this.btn_check.Name = "btn_check";
            this.btn_check.Size = new System.Drawing.Size(100, 23);
            this.btn_check.TabIndex = 7;
            this.btn_check.Text = "Check!";
            this.btn_check.UseVisualStyleBackColor = true;
            this.btn_check.Click += new System.EventHandler(this.btn_check_Click_1);
            // 
            // btnforestgreen
            // 
            this.btnforestgreen.BackColor = System.Drawing.Color.ForestGreen;
            this.btnforestgreen.Location = new System.Drawing.Point(235, 89);
            this.btnforestgreen.Name = "btnforestgreen";
            this.btnforestgreen.Size = new System.Drawing.Size(55, 43);
            this.btnforestgreen.TabIndex = 6;
            this.btnforestgreen.UseVisualStyleBackColor = false;
            this.btnforestgreen.Click += new System.EventHandler(this.btnforestgreen_Click);
            // 
            // btnDarkturkuas
            // 
            this.btnDarkturkuas.BackColor = System.Drawing.Color.DarkTurquoise;
            this.btnDarkturkuas.Location = new System.Drawing.Point(174, 89);
            this.btnDarkturkuas.Name = "btnDarkturkuas";
            this.btnDarkturkuas.Size = new System.Drawing.Size(55, 43);
            this.btnDarkturkuas.TabIndex = 5;
            this.btnDarkturkuas.UseVisualStyleBackColor = false;
            this.btnDarkturkuas.Click += new System.EventHandler(this.btnDarkturkuas_Click);
            // 
            // btnLime
            // 
            this.btnLime.BackColor = System.Drawing.Color.Lime;
            this.btnLime.Location = new System.Drawing.Point(113, 89);
            this.btnLime.Name = "btnLime";
            this.btnLime.Size = new System.Drawing.Size(55, 43);
            this.btnLime.TabIndex = 6;
            this.btnLime.UseVisualStyleBackColor = false;
            this.btnLime.Click += new System.EventHandler(this.btnLime_Click);
            // 
            // btnYellow
            // 
            this.btnYellow.BackColor = System.Drawing.Color.Orange;
            this.btnYellow.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnYellow.Location = new System.Drawing.Point(52, 89);
            this.btnYellow.Name = "btnYellow";
            this.btnYellow.Size = new System.Drawing.Size(55, 43);
            this.btnYellow.TabIndex = 3;
            this.btnYellow.UseVisualStyleBackColor = false;
            this.btnYellow.Click += new System.EventHandler(this.btnOrangeRed_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Beige;
            this.ClientSize = new System.Drawing.Size(420, 135);
            this.Controls.Add(this.btnYellow);
            this.Controls.Add(this.btnLime);
            this.Controls.Add(this.btnDarkturkuas);
            this.Controls.Add(this.btnforestgreen);
            this.Controls.Add(this.btn_check);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tbxAntal);
            this.Controls.Add(this.button1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "Uppgift 10.4a";
            this.TransparencyKey = System.Drawing.Color.Blue;
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox tbxAntal;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_check;
        private System.Windows.Forms.Button btnforestgreen;
        private System.Windows.Forms.Button btnDarkturkuas;
        private System.Windows.Forms.Button btnLime;
        private System.Windows.Forms.Button btnYellow;
    }
}

