﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace uppgift_10._4a
{
    public partial class Form1 : Form
    {
        bool rita = false;
        Color color = Color.Red;
        
        public Form1()
        {
            InitializeComponent();
        }
       

        private void button1_Click(object sender, EventArgs e)
        {
            if (tbxAntal.Text == "")
            {
                tbxAntal.Text = "Please enter a number!";
                return;
            }
            rita = true;
            color = Color.Red;
            Invalidate();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            if (rita) { 
            Graphics g = e.Graphics;
                int antal = int.Parse(tbxAntal.Text);
                SolidBrush brush = new SolidBrush(color);// byt fägr här!
                int x = 10;
                for(int i = 0; i < antal; i++)
                { 
                g.FillEllipse(brush, x, 50, 25, 25);
                    x += 25;
                }

            }

        }

        private void tbxAntal_TextChanged(object sender, EventArgs e)
        {
            rita = false;
            Invalidate();
        }


        //Second form 
       
        private void btnOrangeRed_Click(object sender, EventArgs e)
        {
            color = Color.Orange;
            Invalidate();
        }

        private void btnLime_Click(object sender, EventArgs e)
        {
            color = Color.Lime;
            Invalidate();
        }

        private void btnDarkturkuas_Click(object sender, EventArgs e)
        {
            color = Color.DarkTurquoise;
            Invalidate();
        }

        private void btnforestgreen_Click(object sender, EventArgs e)
        {

            color = Color.ForestGreen;
            Invalidate();

        }
        private void btn_check_Click(object sender, EventArgs e)
        {
            
        }

        private void btn_check_Click_1(object sender, EventArgs e)
        {
            Form2 frm = new Form2();
            frm.Show();
        }
    }
}
